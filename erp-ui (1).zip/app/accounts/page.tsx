import { AccountsTable } from "@/components/accounts-table"

export default function AccountsPage() {
  return (
    <main className="p-6 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl md:text-3xl font-semibold text-balance">Accounts</h1>
        <p className="text-muted-foreground">Companies and organizations you’re working with.</p>
      </header>

      <AccountsTable />
    </main>
  )
}
