import { ContactsTable } from "@/components/contacts-table"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Contacts",
}

export default function ContactsPage() {
  return (
    <main className="p-4 md:p-6">
      <section className="mx-auto max-w-6xl space-y-4">
        <header className="space-y-1">
          <h1 className="text-2xl font-semibold text-pretty">Contacts</h1>
          <p className="text-muted-foreground">View and manage individual contacts across your accounts.</p>
        </header>
        <ContactsTable />
      </section>
    </main>
  )
}

export { default } from "../../app/contacts/page"
