import { InvoicesTable } from "@/components/invoices-table"

export default function InvoicesPage() {
  return (
    <main className="p-6 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl md:text-3xl font-semibold text-balance">Invoices</h1>
        <p className="text-muted-foreground">Track billing and payment status.</p>
      </header>

      <InvoicesTable />
    </main>
  )
}
