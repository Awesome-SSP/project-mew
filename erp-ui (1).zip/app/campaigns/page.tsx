import { CampaignsList } from "@/components/campaigns-list"

export default function CampaignsPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Campaigns</h1>
        <p className="mt-1 text-muted-foreground">Create, monitor, and optimize campaigns with A/B testing.</p>
      </header>
      <CampaignsList />
    </main>
  )
}
