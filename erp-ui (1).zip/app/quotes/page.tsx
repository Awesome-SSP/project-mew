import { QuotesTable } from "@/components/quotes-table"

export default function QuotesPage() {
  return (
    <main className="p-6 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl md:text-3xl font-semibold text-balance">Quotes</h1>
        <p className="text-muted-foreground">Draft, send, and track proposal status.</p>
      </header>

      <QuotesTable />
    </main>
  )
}
