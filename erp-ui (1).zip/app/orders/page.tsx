import { OrdersTable } from "@/components/orders-table"

export default function OrdersPage() {
  return (
    <main className="p-6 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl md:text-3xl font-semibold text-balance">Orders</h1>
        <p className="text-muted-foreground">Manage order fulfillment and status.</p>
      </header>

      <OrdersTable />
    </main>
  )
}
