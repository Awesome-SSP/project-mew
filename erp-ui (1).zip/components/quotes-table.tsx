"use client"

import { useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Quote = {
  id: string
  number: string
  account: string
  owner: string
  amount: number
  status: "Draft" | "Sent" | "Accepted" | "Rejected"
  updatedAt: string
}

const SAMPLE_QUOTES: Quote[] = [
  {
    id: "q1",
    number: "Q-10021",
    account: "Acme Corp",
    owner: "Jane Cooper",
    amount: 14500,
    status: "Accepted",
    updatedAt: "2025-08-10",
  },
  {
    id: "q2",
    number: "Q-10022",
    account: "Globex",
    owner: "Wade Warren",
    amount: 8900,
    status: "Sent",
    updatedAt: "2025-08-09",
  },
  {
    id: "q3",
    number: "Q-10023",
    account: "Initech",
    owner: "Cody Fisher",
    amount: 12000,
    status: "Draft",
    updatedAt: "2025-08-01",
  },
  {
    id: "q4",
    number: "Q-10024",
    account: "Umbrella",
    owner: "Theresa Webb",
    amount: 19900,
    status: "Rejected",
    updatedAt: "2025-07-30",
  },
]

export function QuotesTable() {
  const [q, setQ] = useState("")
  const [status, setStatus] = useState<string>("all")

  const data = useMemo(() => {
    return SAMPLE_QUOTES.filter((x) => {
      const matchesQ =
        q.trim().length === 0 ||
        x.number.toLowerCase().includes(q.toLowerCase()) ||
        x.account.toLowerCase().includes(q.toLowerCase()) ||
        x.owner.toLowerCase().includes(q.toLowerCase())
      const matchesStatus = status === "all" || x.status === status
      return matchesQ && matchesStatus
    })
  }, [q, status])

  return (
    <Card className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search quotes..."
          aria-label="Search quotes"
          className="md:max-w-xs"
        />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full md:w-48" aria-label="Filter by status">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="Draft">Draft</SelectItem>
            <SelectItem value="Sent">Sent</SelectItem>
            <SelectItem value="Accepted">Accepted</SelectItem>
            <SelectItem value="Rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <div className="md:ml-auto flex items-center gap-2">
          <Button size="sm" variant="outline">
            Import
          </Button>
          <Button size="sm">New quote</Button>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left font-medium p-3">Quote #</th>
              <th className="text-left font-medium p-3">Account</th>
              <th className="text-left font-medium p-3">Owner</th>
              <th className="text-left font-medium p-3">Amount</th>
              <th className="text-left font-medium p-3">Status</th>
              <th className="text-left font-medium p-3">Updated</th>
              <th className="text-right font-medium p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((x) => (
              <tr key={x.id} className="border-t">
                <td className="p-3">{x.number}</td>
                <td className="p-3">{x.account}</td>
                <td className="p-3">{x.owner}</td>
                <td className="p-3">${x.amount.toLocaleString()}</td>
                <td className="p-3">
                  <span className="inline-flex items-center rounded px-2 py-1 text-xs bg-secondary">{x.status}</span>
                </td>
                <td className="p-3">{x.updatedAt}</td>
                <td className="p-3 text-right">
                  <Button size="sm" variant="ghost" aria-label={`View ${x.number}`}>
                    View
                  </Button>
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td colSpan={7} className="p-6 text-center text-muted-foreground">
                  No quotes found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
