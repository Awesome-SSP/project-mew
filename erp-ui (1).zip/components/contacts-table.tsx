"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

type Contact = {
  id: string
  name: string
  email: string
  phone: string
  account: string
  status: "Active" | "Marketing" | "Unsubscribed"
  lastActivity: string
}

const DATA: Contact[] = [
  {
    id: "c-1",
    name: "Olivia Martin",
    email: "olivia@example.com",
    phone: "(555) 212-9988",
    account: "Acme Corp",
    status: "Active",
    lastActivity: "2d ago",
  },
  {
    id: "c-2",
    name: "Jackson Lee",
    email: "jackson@example.com",
    phone: "(555) 444-2233",
    account: "Globex",
    status: "Marketing",
    lastActivity: "6h ago",
  },
  {
    id: "c-3",
    name: "Ava Chen",
    email: "ava@example.com",
    phone: "(555) 555-1199",
    account: "Wayne Enterprises",
    status: "Unsubscribed",
    lastActivity: "30d ago",
  },
]

function StatusBadge({ status }: { status: Contact["status"] }) {
  const variant = status === "Active" ? "success" : status === "Marketing" ? "secondary" : "destructive"
  return <Badge variant={variant as any}>{status}</Badge>
}

export function ContactsTable() {
  const [q, setQ] = React.useState("")
  const [status, setStatus] = React.useState<string>("all")

  const filtered = DATA.filter((d) => {
    const matchesQuery =
      q.trim().length === 0 ||
      d.name.toLowerCase().includes(q.toLowerCase()) ||
      d.email.toLowerCase().includes(q.toLowerCase())
    const matchesStatus = status === "all" || d.status === status
    return matchesQuery && matchesStatus
  })

  return (
    <Card>
      <CardHeader className="gap-2">
        <CardTitle className="text-pretty">Contacts</CardTitle>
        <div className="flex flex-col gap-3 md:flex-row md:items-end">
          <div className="flex-1">
            <Label htmlFor="contact-search">Search</Label>
            <Input
              id="contact-search"
              placeholder="Search by name or email"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Search contacts by name or email"
            />
          </div>
          <div>
            <Label className="sr-only" htmlFor="contact-status">
              Status
            </Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger id="contact-status" className="w-[180px]" aria-label="Filter by status">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Marketing">Marketing</SelectItem>
                <SelectItem value="Unsubscribed">Unsubscribed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:ml-auto">
            <Button aria-label="Add contact">Add Contact</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-muted-foreground">
            <tr className="text-left">
              <th className="py-2 pr-4 font-medium">Name</th>
              <th className="py-2 pr-4 font-medium">Email</th>
              <th className="py-2 pr-4 font-medium">Phone</th>
              <th className="py-2 pr-4 font-medium">Account</th>
              <th className="py-2 pr-4 font-medium">Status</th>
              <th className="py-2 pr-0 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((row) => (
              <tr key={row.id} className="border-b last:border-0">
                <td className="py-3 pr-4">{row.name}</td>
                <td className="py-3 pr-4">{row.email}</td>
                <td className="py-3 pr-4">{row.phone}</td>
                <td className="py-3 pr-4">{row.account}</td>
                <td className="py-3 pr-4">
                  <StatusBadge status={row.status} />
                </td>
                <td className="py-3 pr-0 text-right">
                  <div className="inline-flex gap-2">
                    <Button variant="secondary" size="sm" aria-label={`View ${row.name}`}>
                      View
                    </Button>
                    <Button variant="outline" size="sm" aria-label={`Email ${row.name}`}>
                      Email
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="py-6 text-center text-muted-foreground">
                  No contacts match your filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  )
}
