"use client"

import { useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Order = {
  id: string
  number: string
  account: string
  owner: string
  total: number
  status: "Processing" | "Shipped" | "Delivered" | "Cancelled"
  placedAt: string
}

const SAMPLE_ORDERS: Order[] = [
  {
    id: "o1",
    number: "ORD-9001",
    account: "Acme Corp",
    owner: "Jane Cooper",
    total: 24500,
    status: "Processing",
    placedAt: "2025-08-12",
  },
  {
    id: "o2",
    number: "ORD-9002",
    account: "Globex",
    owner: "Wade Warren",
    total: 12900,
    status: "Shipped",
    placedAt: "2025-08-10",
  },
  {
    id: "o3",
    number: "ORD-9003",
    account: "Initech",
    owner: "Cody Fisher",
    total: 5900,
    status: "Delivered",
    placedAt: "2025-08-01",
  },
]

export function OrdersTable() {
  const [q, setQ] = useState("")
  const [status, setStatus] = useState<string>("all")

  const data = useMemo(() => {
    return SAMPLE_ORDERS.filter((x) => {
      const matchesQ =
        q.trim().length === 0 ||
        x.number.toLowerCase().includes(q.toLowerCase()) ||
        x.account.toLowerCase().includes(q.toLowerCase()) ||
        x.owner.toLowerCase().includes(q.toLowerCase())
      const matchesStatus = status === "all" || x.status === status
      return matchesQ && matchesStatus
    })
  }, [q, status])

  return (
    <Card className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search orders..."
          aria-label="Search orders"
          className="md:max-w-xs"
        />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full md:w-48" aria-label="Filter by status">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="Processing">Processing</SelectItem>
            <SelectItem value="Shipped">Shipped</SelectItem>
            <SelectItem value="Delivered">Delivered</SelectItem>
            <SelectItem value="Cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <div className="md:ml-auto flex items-center gap-2">
          <Button size="sm" variant="outline">
            Export
          </Button>
          <Button size="sm">New order</Button>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left font-medium p-3">Order #</th>
              <th className="text-left font-medium p-3">Account</th>
              <th className="text-left font-medium p-3">Owner</th>
              <th className="text-left font-medium p-3">Total</th>
              <th className="text-left font-medium p-3">Status</th>
              <th className="text-left font-medium p-3">Placed</th>
              <th className="text-right font-medium p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((x) => (
              <tr key={x.id} className="border-t">
                <td className="p-3">{x.number}</td>
                <td className="p-3">{x.account}</td>
                <td className="p-3">{x.owner}</td>
                <td className="p-3">${x.total.toLocaleString()}</td>
                <td className="p-3">
                  <span className="inline-flex items-center rounded px-2 py-1 text-xs bg-secondary">{x.status}</span>
                </td>
                <td className="p-3">{x.placedAt}</td>
                <td className="p-3 text-right">
                  <Button size="sm" variant="ghost" aria-label={`View ${x.number}`}>
                    View
                  </Button>
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td colSpan={7} className="p-6 text-center text-muted-foreground">
                  No orders found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
