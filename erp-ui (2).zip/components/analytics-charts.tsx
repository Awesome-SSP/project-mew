"use client"

import {
  ResponsiveContainer,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  LineChart,
  Line,
  BarChart,
  Bar,
} from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const roiTrend = [
  { month: "Jan", roi: 128 },
  { month: "Feb", roi: 134 },
  { month: "Mar", roi: 141 },
  { month: "Apr", roi: 152 },
  { month: "May", roi: 158 },
  { month: "Jun", roi: 164 },
]

const cacLtv = [
  { segment: "SMB", CAC: 210, LTV: 820 },
  { segment: "Mid", CAC: 320, LTV: 1_420 },
  { segment: "Ent", CAC: 540, LTV: 3_600 },
]

function tooltipStyles() {
  return {
    contentStyle: {
      background: "var(--popover)",
      borderColor: "var(--border)",
      color: "var(--foreground)",
      borderRadius: "8px",
    },
    labelStyle: { color: "var(--foreground)" },
    itemStyle: { color: "var(--foreground)" },
  } as const
}

export function AnalyticsCharts() {
  const styles = tooltipStyles()
  return (
    <section aria-label="Analytics charts" className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">ROI Trend</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={roiTrend} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <YAxis
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                  domain={[0, "dataMax + 20"]}
                />
                <Tooltip {...styles} />
                <Line
                  type="monotone"
                  dataKey="roi"
                  stroke="var(--chart-1)"
                  strokeWidth={2}
                  dot={{ r: 3, stroke: "var(--chart-1)", fill: "var(--chart-1)" }}
                  activeDot={{ r: 5 }}
                />
                <Area type="monotone" dataKey="roi" stroke="transparent" fill="rgba(8,145,178,0.18)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">CAC vs LTV by Segment</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cacLtv} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="segment"
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <YAxis
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <Tooltip {...styles} />
                <Bar dataKey="CAC" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="LTV" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
