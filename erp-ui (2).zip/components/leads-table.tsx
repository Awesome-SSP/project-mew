"use client"

import { useMemo, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type Lead = {
  id: string
  name: string
  email: string
  status: "New" | "Contacted" | "Qualified" | "Nurturing"
  source: "Website" | "Referral" | "Ads" | "Events" | "Outbound"
  owner: string
  score: number
}

const seedLeads: Lead[] = [
  {
    id: "L-1001",
    name: "Ava Phillips",
    email: "ava@northstar.io",
    status: "New",
    source: "Website",
    owner: "Sam",
    score: 78,
  },
  {
    id: "L-1002",
    name: "Jared Cole",
    email: "jared@apexlabs.com",
    status: "Qualified",
    source: "Referral",
    owner: "Lena",
    score: 88,
  },
  {
    id: "L-1003",
    name: "Ivy Chen",
    email: "ivy@folia.dev",
    status: "Contacted",
    source: "Ads",
    owner: "Sam",
    score: 67,
  },
  {
    id: "L-1004",
    name: "Diego Ramos",
    email: "diego@solis.app",
    status: "Nurturing",
    source: "Events",
    owner: "Lee",
    score: 54,
  },
  {
    id: "L-1005",
    name: "Sara Kim",
    email: "sara@evervue.co",
    status: "Qualified",
    source: "Website",
    owner: "Noah",
    score: 92,
  },
  {
    id: "L-1006",
    name: "Tom Becker",
    email: "tom@orbitware.ai",
    status: "Contacted",
    source: "Outbound",
    owner: "Lena",
    score: 61,
  },
  {
    id: "L-1007",
    name: "Nina Patel",
    email: "nina@hightide.io",
    status: "New",
    source: "Ads",
    owner: "Sam",
    score: 49,
  },
  {
    id: "L-1008",
    name: "Leo Park",
    email: "leo@stratus.dev",
    status: "Qualified",
    source: "Referral",
    owner: "Lee",
    score: 85,
  },
]

export function LeadsTable() {
  const [q, setQ] = useState("")
  const [status, setStatus] = useState<Lead["status"] | "All">("All")

  const filtered = useMemo(() => {
    const term = q.toLowerCase()
    return seedLeads.filter((l) => {
      const matches =
        l.name.toLowerCase().includes(term) || l.email.toLowerCase().includes(term) || l.id.toLowerCase().includes(term)
      const statusOk = status === "All" ? true : l.status === status
      return matches && statusOk
    })
  }, [q, status])

  return (
    <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Leads</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div className="flex w-full max-w-md items-center gap-2">
            <input
              aria-label="Search leads"
              placeholder="Search by name, email, or ID"
              className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none ring-0 focus:border-border focus:outline-none focus:ring-2 focus:ring-(--ring)"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <Button
              variant="secondary"
              className="bg-secondary text-secondary-foreground hover:opacity-90"
              onClick={() => setQ("")}
            >
              Clear
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="status" className="text-sm text-muted-foreground">
              Status
            </label>
            <select
              id="status"
              className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-(--ring)"
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
            >
              <option>All</option>
              <option>New</option>
              <option>Contacted</option>
              <option>Qualified</option>
              <option>Nurturing</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="border-b px-3 py-2 font-medium">ID</th>
                <th className="border-b px-3 py-2 font-medium">Name</th>
                <th className="border-b px-3 py-2 font-medium">Email</th>
                <th className="border-b px-3 py-2 font-medium">Status</th>
                <th className="border-b px-3 py-2 font-medium">Source</th>
                <th className="border-b px-3 py-2 font-medium">Owner</th>
                <th className="border-b px-3 py-2 font-medium">Score</th>
                <th className="border-b px-3 py-2 font-medium">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => (
                <tr key={l.id} className="hover:bg-muted">
                  <td className="border-b px-3 py-2">{l.id}</td>
                  <td className="border-b px-3 py-2">{l.name}</td>
                  <td className="border-b px-3 py-2">
                    <a className="text-primary underline-offset-2 hover:underline" href={`mailto:${l.email}`}>
                      {l.email}
                    </a>
                  </td>
                  <td className="border-b px-3 py-2">
                    <span
                      className="inline-flex rounded-full bg-secondary/15 px-2 py-0.5 text-xs"
                      aria-label={`Status ${l.status}`}
                    >
                      {l.status}
                    </span>
                  </td>
                  <td className="border-b px-3 py-2">{l.source}</td>
                  <td className="border-b px-3 py-2">{l.owner}</td>
                  <td className="border-b px-3 py-2">{l.score}</td>
                  <td className="border-b px-3 py-2">
                    <div className="flex items-center gap-2">
                      <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
                        Qualify
                      </Button>
                      <Button size="sm" variant="outline">
                        Details
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td className="px-3 py-6 text-center text-muted-foreground" colSpan={8}>
                    No leads found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
