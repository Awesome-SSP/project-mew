"use client"

import { useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

type Account = {
  id: string
  name: string
  owner: string
  industry: string
  stage: "Prospect" | "Customer" | "Churn Risk"
  arr: number
  updatedAt: string
}

const SAMPLE_ACCOUNTS: Account[] = [
  {
    id: "a1",
    name: "Acme Corp",
    owner: "Jane Cooper",
    industry: "Manufacturing",
    stage: "Customer",
    arr: 120000,
    updatedAt: "2025-08-09",
  },
  {
    id: "a2",
    name: "Globex",
    owner: "Wade Warren",
    industry: "Fintech",
    stage: "Prospect",
    arr: 0,
    updatedAt: "2025-08-03",
  },
  {
    id: "a3",
    name: "Initech",
    owner: "Cody Fisher",
    industry: "SaaS",
    stage: "Customer",
    arr: 45000,
    updatedAt: "2025-07-28",
  },
  {
    id: "a4",
    name: "Umbrella",
    owner: "Theresa Webb",
    industry: "Healthcare",
    stage: "Churn Risk",
    arr: 30000,
    updatedAt: "2025-07-21",
  },
]

export function AccountsTable() {
  const [q, setQ] = useState("")
  const [stage, setStage] = useState<string>("all")

  const data = useMemo(() => {
    return SAMPLE_ACCOUNTS.filter((a) => {
      const matchesQ =
        q.trim().length === 0 ||
        a.name.toLowerCase().includes(q.toLowerCase()) ||
        a.owner.toLowerCase().includes(q.toLowerCase()) ||
        a.industry.toLowerCase().includes(q.toLowerCase())
      const matchesStage = stage === "all" || a.stage === stage
      return matchesQ && matchesStage
    })
  }, [q, stage])

  return (
    <Card className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search accounts..."
          aria-label="Search accounts"
          className="md:max-w-xs"
        />
        <Select value={stage} onValueChange={setStage}>
          <SelectTrigger className="w-full md:w-48" aria-label="Filter by stage">
            <SelectValue placeholder="Stage" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All stages</SelectItem>
            <SelectItem value="Prospect">Prospect</SelectItem>
            <SelectItem value="Customer">Customer</SelectItem>
            <SelectItem value="Churn Risk">Churn Risk</SelectItem>
          </SelectContent>
        </Select>
        <div className="md:ml-auto flex items-center gap-2">
          <Button size="sm" variant="outline">
            Import
          </Button>
          <Button size="sm">New account</Button>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left font-medium p-3">Account</th>
              <th className="text-left font-medium p-3">Owner</th>
              <th className="text-left font-medium p-3">Industry</th>
              <th className="text-left font-medium p-3">Stage</th>
              <th className="text-left font-medium p-3">ARR</th>
              <th className="text-left font-medium p-3">Updated</th>
              <th className="text-right font-medium p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((a) => (
              <tr key={a.id} className="border-t">
                <td className="p-3">{a.name}</td>
                <td className="p-3">{a.owner}</td>
                <td className="p-3">{a.industry}</td>
                <td className="p-3">
                  <span className="inline-flex items-center rounded px-2 py-1 text-xs bg-secondary">{a.stage}</span>
                </td>
                <td className="p-3">${a.arr.toLocaleString()}</td>
                <td className="p-3">{a.updatedAt}</td>
                <td className="p-3 text-right">
                  <Button size="sm" variant="ghost" aria-label={`View ${a.name}`}>
                    View
                  </Button>
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td colSpan={7} className="p-6 text-center text-muted-foreground">
                  No accounts found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
