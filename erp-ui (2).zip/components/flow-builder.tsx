"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type StepType = "Trigger" | "Condition" | "Action"

type Step = {
  id: string
  type: StepType
  title: string
  detail?: string
}

const initial: Step[] = [
  { id: "S-1", type: "Trigger", title: "Lead Created", detail: "When a new lead is added" },
  { id: "S-2", type: "Condition", title: "Score ≥ 70", detail: "Qualified leads only" },
  { id: "S-3", type: "Action", title: "Send Email: Welcome Series A", detail: "Send within 1 hour" },
]

export function FlowBuilder() {
  const [steps, setSteps] = useState<Step[]>(initial)

  function addStep(kind: StepType) {
    const id = `S-${crypto.getRandomValues(new Uint32Array(1))[0]}`
    const defaults: Record<StepType, Step> = {
      Trigger: { id, type: "Trigger", title: "New Trigger", detail: "Describe the trigger" },
      Condition: { id, type: "Condition", title: "New Condition", detail: "Describe the condition" },
      Action: { id, type: "Action", title: "New Action", detail: "Describe the action" },
    }
    setSteps((s) => [...s, defaults[kind]])
  }

  function moveUp(index: number) {
    if (index === 0) return
    setSteps((s) => {
      const copy = [...s]
      const tmp = copy[index - 1]
      copy[index - 1] = copy[index]
      copy[index] = tmp
      return copy
    })
  }

  function moveDown(index: number) {
    if (index === steps.length - 1) return
    setSteps((s) => {
      const copy = [...s]
      const tmp = copy[index + 1]
      copy[index + 1] = copy[index]
      copy[index] = tmp
      return copy
    })
  }

  function remove(index: number) {
    setSteps((s) => s.filter((_, i) => i !== index))
  }

  return (
    <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <CardHeader className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <CardTitle className="text-base">Automation Flow</CardTitle>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            className="bg-primary text-primary-foreground hover:opacity-90"
            onClick={() => addStep("Trigger")}
          >
            Add Trigger
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="bg-secondary text-secondary-foreground hover:opacity-90"
            onClick={() => addStep("Condition")}
          >
            Add Condition
          </Button>
          <Button size="sm" variant="outline" onClick={() => addStep("Action")}>
            Add Action
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ol className="relative space-y-4 border-l pl-4">
          {steps.map((s, i) => (
            <li key={s.id} className="group">
              <div
                className={cn(
                  "relative rounded-md border bg-background/60 p-3 shadow-sm",
                  s.type === "Trigger" && "ring-1 ring-primary/20",
                  s.type === "Condition" && "ring-1 ring-secondary/20",
                  s.type === "Action" && "ring-1 ring-foreground/10",
                )}
              >
                {/* timeline dot */}
                <span
                  className={cn(
                    "absolute -left-2 top-4 h-3 w-3 rounded-full border",
                    s.type === "Trigger" ? "bg-primary" : s.type === "Condition" ? "bg-secondary" : "bg-foreground/40",
                  )}
                  aria-hidden="true"
                />
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">{s.type}</div>
                    <div className="text-sm font-semibold">{s.title}</div>
                    {s.detail && <div className="text-xs text-muted-foreground">{s.detail}</div>}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => moveUp(i)} aria-label="Move up">
                      Up
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => moveDown(i)} aria-label="Move down">
                      Down
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => remove(i)} aria-label="Remove">
                      Remove
                    </Button>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  )
}
