"use client"

import type React from "react"

import { useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type Deal = {
  id: string
  name: string
  value: number
  owner: string
  company?: string
  stage: "New" | "In Progress" | "Won"
}

const seedDeals: Deal[] = [
  { id: "D-2001", name: "Apex Labs - Pro", value: 18000, owner: "Lena", company: "Apex Labs", stage: "New" },
  { id: "D-2002", name: "Northstar - Team", value: 9600, owner: "Sam", company: "Northstar", stage: "New" },
  { id: "D-2003", name: "Folia - Enterprise", value: 42000, owner: "Lee", company: "Folia", stage: "In Progress" },
  { id: "D-2004", name: "Orbitware - Pro", value: 15000, owner: "Noah", company: "Orbitware", stage: "In Progress" },
  { id: "D-2005", name: "Solis - Pro", value: 13800, owner: "Sam", company: "Solis", stage: "Won" },
]

function Column({
  title,
  children,
  count,
  highlight,
}: {
  title: string
  count: number
  children: React.ReactNode
  highlight?: "primary" | "secondary"
}) {
  return (
    <section className="flex flex-1 flex-col rounded-lg border bg-card/80 p-3 backdrop-blur supports-[backdrop-filter]:bg-card/70">
      <header className="mb-2 flex items-center justify-between">
        <h2 className="text-sm font-semibold">
          {title} <span className="text-muted-foreground">({count})</span>
        </h2>
        {highlight && (
          <span
            className={cn("h-2 w-2 rounded-full", highlight === "primary" ? "bg-primary" : "bg-secondary")}
            aria-hidden="true"
          />
        )}
      </header>
      <div className="grid gap-2">{children}</div>
    </section>
  )
}

function DealCard({ deal }: { deal: Deal }) {
  return (
    <Card className="rounded-md border bg-background/60 p-3 shadow-sm transition-colors hover:bg-background/80">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-medium leading-6">{deal.name}</div>
          <div className="text-xs text-muted-foreground">
            {deal.company} • Owner: {deal.owner}
          </div>
        </div>
        <div className="text-sm font-semibold">${(deal.value / 1000).toFixed(0)}k</div>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
          Advance
        </Button>
        <Button size="sm" variant="outline">
          Details
        </Button>
      </div>
    </Card>
  )
}

export function PipelineBoard() {
  const grouped = useMemo(() => {
    return {
      New: seedDeals.filter((d) => d.stage === "New"),
      "In Progress": seedDeals.filter((d) => d.stage === "In Progress"),
      Won: seedDeals.filter((d) => d.stage === "Won"),
    }
  }, [])

  return (
    <div className="flex flex-col gap-3 md:flex-row">
      <Column title="New" count={grouped["New"].length} highlight="secondary">
        {grouped["New"].map((d) => (
          <DealCard key={d.id} deal={d} />
        ))}
      </Column>
      <Column title="In Progress" count={grouped["In Progress"].length} highlight="primary">
        {grouped["In Progress"].map((d) => (
          <DealCard key={d.id} deal={d} />
        ))}
      </Column>
      <Column title="Won" count={grouped["Won"].length}>
        {grouped["Won"].map((d) => (
          <DealCard key={d.id} deal={d} />
        ))}
      </Column>
    </div>
  )
}
