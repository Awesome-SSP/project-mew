"use client"

type KPI = { label: string; value: string; sublabel?: string }
export function KpiGrid({ items }: { items: KPI[] }) {
  return (
    <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((kpi) => (
        <div key={kpi.label} className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground">{kpi.label}</div>
          <div className="mt-1 text-2xl font-semibold">{kpi.value}</div>
          {kpi.sublabel && <div className="mt-1 text-xs text-muted-foreground">{kpi.sublabel}</div>}
        </div>
      ))}
    </section>
  )
}
