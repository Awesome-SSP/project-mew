"use client"

import { useMemo, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type CampaignStatus = "Draft" | "Running" | "Paused" | "Completed"
type CampaignChannel = "Email" | "Ads" | "Social" | "Events"

type Campaign = {
  id: string
  name: string
  channel: CampaignChannel
  status: CampaignStatus
  audience: number
  budget: number
  spend: number
  conversions: number
  ab?: { a: number; b: number } // conversion rate in %
}

const seed: Campaign[] = [
  {
    id: "C-3001",
    name: "Spring Promo 20%",
    channel: "Email",
    status: "Running",
    audience: 12000,
    budget: 3500,
    spend: 1800,
    conversions: 420,
    ab: { a: 3.2, b: 4.1 },
  },
  {
    id: "C-3002",
    name: "Brand Awareness Q2",
    channel: "Ads",
    status: "Paused",
    audience: 58000,
    budget: 12000,
    spend: 7200,
    conversions: 830,
    ab: { a: 1.1, b: 1.4 },
  },
  {
    id: "C-3003",
    name: "Founders Webinar",
    channel: "Events",
    status: "Draft",
    audience: 2600,
    budget: 900,
    spend: 0,
    conversions: 0,
  },
  {
    id: "C-3004",
    name: "Launch Countdown",
    channel: "Social",
    status: "Running",
    audience: 22000,
    budget: 2800,
    spend: 900,
    conversions: 310,
    ab: { a: 2.4, b: 2.2 },
  },
  {
    id: "C-3005",
    name: "Winback Series",
    channel: "Email",
    status: "Completed",
    audience: 8000,
    budget: 1500,
    spend: 1470,
    conversions: 560,
    ab: { a: 4.8, b: 5.0 },
  },
]

function ABBar({ a, b }: { a: number; b: number }) {
  const total = a + b || 1
  const aPct = (a / total) * 100
  const bPct = (b / total) * 100
  return (
    <div className="w-full">
      <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
        <span>A: {a.toFixed(1)}%</span>
        <span>B: {b.toFixed(1)}%</span>
      </div>
      <div className="flex h-2 w-full overflow-hidden rounded-full border bg-background">
        <div className="h-full bg-primary" style={{ width: `${aPct}%` }} aria-label={`Variant A ${a.toFixed(1)}%`} />
        <div className="h-full bg-secondary" style={{ width: `${bPct}%` }} aria-label={`Variant B ${b.toFixed(1)}%`} />
      </div>
    </div>
  )
}

export function CampaignsList() {
  const [q, setQ] = useState("")
  const [status, setStatus] = useState<CampaignStatus | "All">("All")
  const [channel, setChannel] = useState<CampaignChannel | "All">("All")

  const filtered = useMemo(() => {
    const term = q.toLowerCase()
    return seed.filter((c) => {
      const matches =
        c.name.toLowerCase().includes(term) ||
        c.id.toLowerCase().includes(term) ||
        c.channel.toLowerCase().includes(term)
      const sOk = status === "All" ? true : c.status === status
      const chOk = channel === "All" ? true : c.channel === channel
      return matches && sOk && chOk
    })
  }, [q, status, channel])

  return (
    <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Campaigns</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div className="flex w-full max-w-md items-center gap-2">
            <input
              aria-label="Search campaigns"
              placeholder="Search by name, ID, or channel"
              className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:outline-none focus:ring-2"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <Button
              variant="secondary"
              className="bg-secondary text-secondary-foreground hover:opacity-90"
              onClick={() => setQ("")}
            >
              Clear
            </Button>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label htmlFor="status" className="text-sm text-muted-foreground">
              Status
            </label>
            <select
              id="status"
              className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2"
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
            >
              <option>All</option>
              <option>Draft</option>
              <option>Running</option>
              <option>Paused</option>
              <option>Completed</option>
            </select>

            <label htmlFor="channel" className="text-sm text-muted-foreground">
              Channel
            </label>
            <select
              id="channel"
              className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2"
              value={channel}
              onChange={(e) => setChannel(e.target.value as any)}
            >
              <option>All</option>
              <option>Email</option>
              <option>Ads</option>
              <option>Social</option>
              <option>Events</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="border-b px-3 py-2 font-medium">ID</th>
                <th className="border-b px-3 py-2 font-medium">Name</th>
                <th className="border-b px-3 py-2 font-medium">Channel</th>
                <th className="border-b px-3 py-2 font-medium">Status</th>
                <th className="border-b px-3 py-2 font-medium">Audience</th>
                <th className="border-b px-3 py-2 font-medium">Budget</th>
                <th className="border-b px-3 py-2 font-medium">Spend</th>
                <th className="border-b px-3 py-2 font-medium">Conversions</th>
                <th className="border-b px-3 py-2 font-medium">A/B</th>
                <th className="border-b px-3 py-2 font-medium">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-muted">
                  <td className="border-b px-3 py-2">{c.id}</td>
                  <td className="border-b px-3 py-2">{c.name}</td>
                  <td className="border-b px-3 py-2">{c.channel}</td>
                  <td className="border-b px-3 py-2">
                    <span className="inline-flex rounded-full bg-primary/10 px-2 py-0.5 text-xs text-foreground">
                      {c.status}
                    </span>
                  </td>
                  <td className="border-b px-3 py-2">{c.audience.toLocaleString()}</td>
                  <td className="border-b px-3 py-2">${c.budget.toLocaleString()}</td>
                  <td className="border-b px-3 py-2">${c.spend.toLocaleString()}</td>
                  <td className="border-b px-3 py-2">{c.conversions.toLocaleString()}</td>
                  <td className="border-b px-3 py-2">
                    {c.ab ? <ABBar a={c.ab.a} b={c.ab.b} /> : <span className="text-muted-foreground">—</span>}
                  </td>
                  <td className="border-b px-3 py-2">
                    <div className="flex items-center gap-2">
                      {c.status === "Running" ? (
                        <Button size="sm" variant="outline">
                          Pause
                        </Button>
                      ) : (
                        <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
                          Start
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="secondary"
                        className="bg-secondary text-secondary-foreground hover:opacity-90"
                      >
                        Duplicate
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td className="px-3 py-6 text-center text-muted-foreground" colSpan={10}>
                    No campaigns found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
