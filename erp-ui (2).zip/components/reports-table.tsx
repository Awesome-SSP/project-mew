"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type ReportRow = {
  id: string
  title: string
  owner: string
  lastRun: string
  status: "OK" | "Needs Attention"
}

const rows: ReportRow[] = [
  { id: "R-9001", title: "Monthly Revenue Summary", owner: "Finance", lastRun: "2025-08-31", status: "OK" },
  { id: "R-9002", title: "Campaign Performance (QTD)", owner: "Marketing", lastRun: "2025-08-30", status: "OK" },
  {
    id: "R-9003",
    title: "Lead Funnel Conversion",
    owner: "Sales Ops",
    lastRun: "2025-08-29",
    status: "Needs Attention",
  },
]

export function ReportsTable() {
  function downloadCSV() {
    const header = ["ID", "Title", "Owner", "Last Run", "Status"]
    const data = rows.map((r) => [r.id, r.title, r.owner, r.lastRun, r.status])
    const csv = [header, ...data]
      .map((line) => line.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "reports.csv"
    a.style.display = "none"
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <CardHeader className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <CardTitle className="text-base">Reports</CardTitle>
        <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90" onClick={downloadCSV}>
          Download CSV
        </Button>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="border-b px-3 py-2 font-medium">ID</th>
                <th className="border-b px-3 py-2 font-medium">Title</th>
                <th className="border-b px-3 py-2 font-medium">Owner</th>
                <th className="border-b px-3 py-2 font-medium">Last Run</th>
                <th className="border-b px-3 py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="hover:bg-muted">
                  <td className="border-b px-3 py-2">{r.id}</td>
                  <td className="border-b px-3 py-2">{r.title}</td>
                  <td className="border-b px-3 py-2">{r.owner}</td>
                  <td className="border-b px-3 py-2">{r.lastRun}</td>
                  <td className="border-b px-3 py-2">
                    <span
                      className={
                        r.status === "OK"
                          ? "inline-flex rounded-full bg-primary/10 px-2 py-0.5 text-xs"
                          : "inline-flex rounded-full bg-secondary/15 px-2 py-0.5 text-xs"
                      }
                      aria-label={`Status ${r.status}`}
                    >
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
