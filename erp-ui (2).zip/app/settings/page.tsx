import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function Page() {
  return (
    <main className="p-4 md:p-6">
      <header className="mb-4">
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Settings</h1>
        <p className="text-sm text-muted-foreground">Update your profile and preferences.</p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Label htmlFor="name">Name</Label>
            <Input id="name" placeholder="Your name" />

            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="you@example.com" />

            <div>
              <Button aria-label="Save profile">Save</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications">Email notifications</Label>
              <Switch id="notifications" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="density">Density</Label>
              <Select>
                <SelectTrigger id="density" aria-label="Density">
                  <SelectValue placeholder="Comfortable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="comfortable">Comfortable</SelectItem>
                  <SelectItem value="compact">Compact</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
