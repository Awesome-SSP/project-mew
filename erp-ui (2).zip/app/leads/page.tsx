import { LeadsTable } from "@/components/leads-table"

export default function LeadsPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Leads</h1>
        <p className="mt-1 text-muted-foreground">Search, qualify, and manage inbound and outbound leads.</p>
      </header>
      <LeadsTable />
    </main>
  )
}
