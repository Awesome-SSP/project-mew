import { FlowBuilder } from "@/components/flow-builder"

export default function AutomationPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Automation</h1>
        <p className="mt-1 text-muted-foreground">
          Build flows that react to triggers, check conditions, and perform actions automatically.
        </p>
      </header>
      <FlowBuilder />
    </main>
  )
}
