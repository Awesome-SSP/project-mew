import { PipelineBoard } from "@/components/pipeline-board"

export default function PipelinePage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Pipeline</h1>
        <p className="mt-1 text-muted-foreground">Track opportunities across stages and focus on what wins.</p>
      </header>
      <PipelineBoard />
    </main>
  )
}
