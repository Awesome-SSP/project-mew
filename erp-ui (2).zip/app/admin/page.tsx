import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function Page() {
  return (
    <main className="p-4 md:p-6">
      <header className="mb-4">
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Admin</h1>
        <p className="text-sm text-muted-foreground">Role management and audit logs (placeholder).</p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>User Roles</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="invite-email">Invite user</Label>
              <div className="flex items-center gap-2">
                <Input id="invite-email" type="email" placeholder="user@example.com" />
                <Button aria-label="Invite user">Invite</Button>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Add or remove users and assign roles. (Placeholder)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Audit Log</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid gap-2 text-sm text-muted-foreground">
              <li>• You invited Sam (viewer)</li>
              <li>• Alex changed pipeline stage visibility</li>
              <li>• System rotated API keys</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
