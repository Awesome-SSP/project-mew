"use client"

import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"

export default function ComingSoonPage() {
  const params = useSearchParams()
  const target = params.get("target") || "This feature"

  return (
    <main className="mx-auto w-full max-w-2xl px-6 py-10">
      <div className="rounded-lg border bg-card p-6">
        <h1 className="mb-2 text-balance text-2xl font-semibold">{target} is coming soon</h1>
        <p className="text-pretty text-muted-foreground">
          We’re building this section now. In the meantime, explore the available modules from the sidebar.
        </p>
        <div className="mt-6">
          <Button asChild>
            <Link href="/">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}
