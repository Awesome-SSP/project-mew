export { default as Badge } from './Badge.vue'
export type { BadgeProps } from './types'
