export { default as FileUploader } from './FileUploader.vue'
