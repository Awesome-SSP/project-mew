export { default as Tree } from './Tree.vue'
export type { TreeProps } from './types'