export { default as TextInput } from './TextInput.vue'
export type { TextInputProps } from './types'