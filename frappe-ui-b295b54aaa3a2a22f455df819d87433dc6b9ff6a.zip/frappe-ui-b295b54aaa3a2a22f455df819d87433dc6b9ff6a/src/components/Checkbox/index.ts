export { default as Checkbox } from './Checkbox.vue'
export type { CheckboxProps } from './types'