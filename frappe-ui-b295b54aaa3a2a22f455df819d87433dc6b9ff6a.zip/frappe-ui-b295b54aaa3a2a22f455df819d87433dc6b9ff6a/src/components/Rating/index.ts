export { default as Rating } from './Rating.vue'
export type { RatingProps } from './types'