export { default as Divider } from './Divider.vue'
export type { DividerProps } from './types'