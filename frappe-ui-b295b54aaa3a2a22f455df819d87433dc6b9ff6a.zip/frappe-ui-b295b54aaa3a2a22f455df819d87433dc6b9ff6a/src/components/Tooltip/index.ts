export { default as Tooltip } from './Tooltip.vue'
export type { TooltipProps } from './types'