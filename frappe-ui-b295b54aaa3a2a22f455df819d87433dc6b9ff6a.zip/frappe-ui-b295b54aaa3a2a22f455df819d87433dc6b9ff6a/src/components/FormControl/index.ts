export { default as FormControl } from './FormControl.vue'
export type { FormControlProps } from './types'
