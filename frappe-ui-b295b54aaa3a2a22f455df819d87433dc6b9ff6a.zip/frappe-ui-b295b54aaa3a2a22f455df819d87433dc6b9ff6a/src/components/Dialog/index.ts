export { default as Dialog } from './Dialog.vue'
export type { DialogProps } from './types'