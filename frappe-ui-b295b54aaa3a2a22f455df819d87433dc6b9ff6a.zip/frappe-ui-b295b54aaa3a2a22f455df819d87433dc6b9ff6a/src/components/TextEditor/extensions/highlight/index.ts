export { NamedHighlightExtension, default } from './highlight-extension'
export type { HighlightOptions } from './highlight-extension'
