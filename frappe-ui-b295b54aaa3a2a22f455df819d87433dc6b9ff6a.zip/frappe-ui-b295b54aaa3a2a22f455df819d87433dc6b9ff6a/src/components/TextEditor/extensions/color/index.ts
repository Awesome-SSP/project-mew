export { NamedColorExtension, default } from './color-extension'
export type { ColorOptions } from './color-extension'
