export {
  ImageExtension,
  type ImageExtensionOptions,
  type SetImageOptions,
} from './image-extension'
