export { default as Textarea } from './Textarea.vue'
export type { TextareaProps } from './types'