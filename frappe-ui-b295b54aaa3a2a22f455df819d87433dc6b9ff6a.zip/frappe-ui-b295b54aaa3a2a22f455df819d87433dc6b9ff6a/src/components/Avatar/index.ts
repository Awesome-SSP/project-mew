export { default as Avatar } from './Avatar.vue'
export type { AvatarProps } from './types'
