export { default as CircularProgressBar } from './CircularProgressBar.vue'
export type { CircularProgressBarProps } from './types'