export { default as ErrorMessage } from './ErrorMessage.vue'
export type { ErrorMessageProps } from './types'