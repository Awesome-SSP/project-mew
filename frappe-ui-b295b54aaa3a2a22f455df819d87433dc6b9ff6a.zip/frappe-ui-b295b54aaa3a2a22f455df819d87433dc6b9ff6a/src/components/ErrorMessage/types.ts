export interface ErrorMessageProps {
  message?: string | Error
}
