export { default as Switch } from './Switch.vue'
export type { SwitchProps } from './types'