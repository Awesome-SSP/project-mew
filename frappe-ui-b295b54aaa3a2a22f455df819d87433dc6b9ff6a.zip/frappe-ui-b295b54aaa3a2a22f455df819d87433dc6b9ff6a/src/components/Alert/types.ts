export interface AlertProps {
  title?: string
  type?: 'warning'
}
