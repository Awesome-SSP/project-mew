export { default as Progress } from './Progress.vue'
export type { ProgressProps } from './types'