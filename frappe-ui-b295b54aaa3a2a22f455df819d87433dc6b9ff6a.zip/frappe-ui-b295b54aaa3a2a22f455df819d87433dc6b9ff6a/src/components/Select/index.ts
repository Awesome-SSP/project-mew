export { default as Select } from './Select.vue'
export type { SelectProps } from './types'