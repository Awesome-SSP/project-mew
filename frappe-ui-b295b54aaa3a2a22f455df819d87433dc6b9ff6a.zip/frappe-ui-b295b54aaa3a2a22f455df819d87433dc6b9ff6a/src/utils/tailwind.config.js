import preset from '../tailwind/preset.js'
console.warn(
  '`frappe-ui/src/utils/tailwind.config.js` is deprecated. Use `frappe-ui/tailwind/preset.js` instead.',
)
// keep backwards compatible for now
export default preset
