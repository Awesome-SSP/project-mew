import { ref } from 'vue'

export const showHelpCenter = ref(false)
