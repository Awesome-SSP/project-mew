import { ref } from 'vue'

export const showHelpModal = ref(false)
export const minimize = ref(false)
