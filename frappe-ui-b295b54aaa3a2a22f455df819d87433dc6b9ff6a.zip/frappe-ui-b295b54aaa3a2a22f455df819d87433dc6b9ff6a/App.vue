<script setup>
import { Badge } from './src'
</script>

<template>
  <Badge> Gamma </Badge>
</template>
