"use client"

import { useMemo, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type Task = { id: string; title: string; done: boolean; assignee?: string }

const initialTasks: Task[] = [
  { id: "T-1", title: "Review Q3 campaign plan", done: false, assignee: "Lena" },
  { id: "T-2", title: "Sync with Sales on targets", done: true, assignee: "Sam" },
  { id: "T-3", title: "Prepare webinar assets", done: false, assignee: "Lee" },
]

type Comment = { id: string; author: string; text: string; at: string }
const initialComments: Comment[] = [
  { id: "C-1", author: "Lena", text: "Draft deck uploaded for review.", at: "10:14" },
  { id: "C-2", author: "Sam", text: "Updated MQL definition per ops.", at: "09:02" },
]

export function CollaborationPanel() {
  const [notes, setNotes] = useState("Team notes: goals, blockers, decisions…")
  const [tasks, setTasks] = useState<Task[]>(initialTasks)
  const [taskTitle, setTaskTitle] = useState("") // <- new
  const [commentText, setCommentText] = useState("") // <- new
  const [comments, setComments] = useState<Comment[]>(initialComments)

  const doneCount = useMemo(() => tasks.filter((t) => t.done).length, [tasks])

  function toggleTask(id: string) {
    setTasks((ts) => ts.map((t) => (t.id === id ? { ...t, done: !t.done } : t)))
  }

  function addTask() {
    if (!taskTitle.trim()) return
    const id = `T-${Date.now()}`
    setTasks((ts) => [{ id, title: taskTitle.trim(), done: false }, ...ts])
    setTaskTitle("")
  }

  function addComment() {
    if (!commentText.trim()) return
    const id = `C-${Date.now()}`
    const at = new Date().toTimeString().slice(0, 5)
    setComments((cs) => [{ id, author: "You", text: commentText.trim(), at }, ...cs])
    setCommentText("")
  }

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      {/* Notes */}
      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">Shared Notes</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <label htmlFor="notes" className="sr-only">
            Team notes
          </label>
          <textarea
            id="notes"
            className="min-h-40 w-full rounded-md border bg-background p-3 text-sm outline-none focus:ring-2"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            aria-label="Shared team notes"
          />
          <div className="mt-2 text-xs text-muted-foreground">{notes.length} characters</div>
        </CardContent>
      </Card>

      {/* Tasks */}
      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">
            Team Tasks{" "}
            <span className="text-foreground">
              ({doneCount}/{tasks.length})
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-2">
          <div className="flex items-center gap-2">
            <input
              aria-label="Quick add task"
              placeholder="Add new task"
              className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
            />
            <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90" onClick={addTask}>
              Add
            </Button>
          </div>
          <ul className="grid gap-2">
            {tasks.map((t) => (
              <li key={t.id} className="flex items-center justify-between rounded-md border bg-background/60 p-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={t.done}
                    onChange={() => toggleTask(t.id)}
                    aria-label={`Mark "${t.title}" ${t.done ? "undone" : "done"}`}
                  />
                  <span className={t.done ? "line-through text-muted-foreground" : ""}>{t.title}</span>
                </label>
                {t.assignee && <span className="text-xs text-muted-foreground">Owner: {t.assignee}</span>}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Comments */}
      <Card className="md:col-span-2 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">Comments</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-2">
          <div className="flex items-center gap-2">
            <input
              aria-label="Write a comment"
              placeholder="Write a comment…"
              className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
            />
            <Button
              variant="secondary"
              className="bg-secondary text-secondary-foreground hover:opacity-90"
              onClick={addComment}
            >
              Comment
            </Button>
          </div>
          <ul className="grid gap-2">
            {comments.map((c) => (
              <li key={c.id} className="rounded-md border bg-background/60 p-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">{c.author}</div>
                  <div className="text-xs text-muted-foreground">{c.at}</div>
                </div>
                <div className="text-sm">{c.text}</div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
