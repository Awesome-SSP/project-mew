export function ComingSoon({ feature = "This feature" }: { feature?: string }) {
  return (
    <div className="rounded-lg border bg-card p-6">
      <h2 className="text-xl font-semibold">{feature}</h2>
      <p className="text-muted-foreground">
        Coming soon. This page is a placeholder to avoid broken links while we build the full module.
      </p>
    </div>
  )
}
