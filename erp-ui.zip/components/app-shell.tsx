"use client"

import type React from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type NavItem = { href: string; label: string }
type NavGroup = { id: string; label: string; items: NavItem[] }

const knownRoutes = new Set<string>([
  "/",
  "/leads",
  "/pipeline",
  "/campaigns",
  "/automation",
  "/analytics",
  "/collaboration",
  "/integrations",
  "/settings",
  "/admin",
])

function safeHref(item: NavItem) {
  return knownRoutes.has(item.href) ? item.href : `/coming-soon?target=${encodeURIComponent(item.label)}`
}

const groups: NavGroup[] = [
  {
    id: "sales",
    label: "Sales",
    items: [
      { href: "/", label: "Dashboard" },
      { href: "/leads", label: "Leads" },
      { href: "/pipeline", label: "Pipeline" },
      { href: "/accounts-contacts", label: "Accounts & Contacts" },
      { href: "/quotations-invoices", label: "Quotations & Invoices" },
      { href: "/orders", label: "Orders" },
    ],
  },
  {
    id: "marketing",
    label: "Marketing",
    items: [
      { href: "/campaigns", label: "Campaigns" },
      { href: "/content-hub", label: "Content Hub" },
      { href: "/events", label: "Events" },
      { href: "/landing-pages", label: "Landing Pages" },
      { href: "/seo-ads", label: "SEO & Ads" },
    ],
  },
  {
    id: "automation",
    label: "Automation",
    items: [
      { href: "/automation", label: "Workflow Builder" },
      { href: "/triggers-rules", label: "Triggers & Rules" },
      { href: "/drip-campaigns", label: "Drip Campaigns" },
    ],
  },
  {
    id: "analytics",
    label: "Analytics",
    items: [
      { href: "/analytics", label: "Reports" },
      { href: "/forecasts", label: "Forecasts" },
      { href: "/competitor-insights", label: "Competitor Insights" },
    ],
  },
  {
    id: "collaboration",
    label: "Collaboration",
    items: [
      { href: "/collaboration", label: "Tasks & Projects" },
      { href: "/documents", label: "Documents" },
      { href: "/meetings", label: "Meetings" },
    ],
  },
  {
    id: "integrations",
    label: "Integrations",
    items: [
      { href: "/integrations", label: "CRM" },
      { href: "/social-media", label: "Social Media" },
      { href: "/payment-gateways", label: "Payment Gateways" },
    ],
  },
  {
    id: "admin",
    label: "Settings & Admin",
    items: [
      { href: "/settings", label: "Roles & Permissions" },
      { href: "/audit-logs", label: "Audit Logs" },
      { href: "/customization", label: "Customization" },
      { href: "/admin", label: "Admin" },
    ],
  },
]

function ThemeToggle() {
  const [mounted, setMounted] = useState(false)
  const [theme, setTheme] = useState<"light" | "dark">("light")

  useEffect(() => {
    setMounted(true)
    const stored = typeof window !== "undefined" ? (localStorage.getItem("theme") as "light" | "dark" | null) : null
    const initial = stored ?? (document.documentElement.classList.contains("dark") ? "dark" : "light")
    document.documentElement.classList.toggle("dark", initial === "dark")
    setTheme(initial)
  }, [])

  if (!mounted) return null

  const isDark = theme === "dark"
  return (
    <Button
      variant="outline"
      size="sm"
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      onClick={() => {
        const next = isDark ? "light" : "dark"
        document.documentElement.classList.toggle("dark", next === "dark")
        localStorage.setItem("theme", next)
        setTheme(next)
      }}
    >
      <span className="sr-only">{isDark ? "Light mode" : "Dark mode"}</span>
      {isDark ? "Light" : "Dark"}
    </Button>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex">
        {/* Desktop Sidebar */}
        <aside
          className="relative hidden w-60 shrink-0 border-r bg-sidebar text-sidebar-foreground md:block"
          aria-label="Primary"
        >
          <div className="flex h-16 items-center justify-between px-4">
            <Link href="/" className="font-semibold tracking-tight">
              S&M ERP
            </Link>
          </div>
          <nav className="px-2 py-2">
            {(() => {
              const openGroups = groups.filter((g) => g.items.some((it) => pathname === it.href)).map((g) => g.id)
              return (
                <Accordion type="multiple" defaultValue={openGroups} className="space-y-1">
                  {groups.map((group) => (
                    <AccordionItem key={group.id} value={group.id} className="border-none">
                      <AccordionTrigger className="px-3 py-2 text-sm hover:no-underline">
                        <span className="text-foreground/90">{group.label}</span>
                      </AccordionTrigger>
                      <AccordionContent className="px-1 pb-2">
                        <ul className="space-y-1">
                          {group.items.map((item) => {
                            const href = safeHref(item)
                            const active = pathname === item.href || pathname === href
                            return (
                              <li key={item.label}>
                                <Link
                                  href={href}
                                  className={cn(
                                    "flex items-center gap-2 rounded-md px-3 py-2 text-sm",
                                    active
                                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                                      : "hover:bg-muted hover:text-foreground",
                                  )}
                                  aria-current={active ? "page" : undefined}
                                >
                                  <span
                                    className={cn(
                                      "h-1.5 w-1.5 rounded-full",
                                      active ? "bg-white/90" : "bg-foreground/40",
                                    )}
                                    aria-hidden="true"
                                  />
                                  <span>{item.label}</span>
                                </Link>
                              </li>
                            )
                          })}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )
            })()}
          </nav>
        </aside>

        {/* Mobile Sidebar / Overlay */}
        <div className="md:hidden">
          <div
            className={cn(
              "fixed inset-0 z-40 bg-black/40 transition-opacity",
              open ? "opacity-100" : "pointer-events-none opacity-0",
            )}
            aria-hidden="true"
            onClick={() => setOpen(false)}
          />
          <aside
            id="mobile-sidebar"
            className={cn(
              "fixed inset-y-0 left-0 z-50 w-64 border-r bg-sidebar text-sidebar-foreground transition-transform",
              open ? "translate-x-0" : "-translate-x-full",
            )}
            aria-label="Primary"
          >
            <div className="flex h-16 items-center justify-between px-4">
              <Link href="/" className="font-semibold tracking-tight" onClick={() => setOpen(false)}>
                S&M ERP
              </Link>
              <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>
                <span className="sr-only">Close menu</span>Close
              </Button>
            </div>
            <nav className="px-2 py-2 overflow-y-auto">
              {(() => {
                const openGroups = groups.filter((g) => g.items.some((it) => pathname === it.href)).map((g) => g.id)
                return (
                  <Accordion type="multiple" defaultValue={openGroups} className="space-y-1">
                    {groups.map((group) => (
                      <AccordionItem key={group.id} value={group.id} className="border-none">
                        <AccordionTrigger className="px-3 py-2 text-sm hover:no-underline">
                          <span className="text-foreground/90">{group.label}</span>
                        </AccordionTrigger>
                        <AccordionContent className="px-1 pb-2">
                          <ul className="space-y-1">
                            {group.items.map((item) => {
                              const href = safeHref(item)
                              const active = pathname === item.href || pathname === href
                              return (
                                <li key={item.label}>
                                  <Link
                                    href={href}
                                    className={cn(
                                      "flex items-center gap-2 rounded-md px-3 py-2 text-sm",
                                      active
                                        ? "bg-sidebar-primary text-sidebar-primary-foreground"
                                        : "hover:bg-muted hover:text-foreground",
                                    )}
                                    aria-current={active ? "page" : undefined}
                                    onClick={() => setOpen(false)}
                                  >
                                    <span
                                      className={cn(
                                        "h-1.5 w-1.5 rounded-full",
                                        active ? "bg-white/90" : "bg-foreground/40",
                                      )}
                                      aria-hidden="true"
                                    />
                                    <span>{item.label}</span>
                                  </Link>
                                </li>
                              )
                            })}
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                )
              })()}
            </nav>
          </aside>
        </div>

        {/* Content Column */}
        <div className="flex min-h-screen flex-1 flex-col">
          {/* Topbar */}
          <header className="sticky top-0 z-30 border-b bg-card/80 backdrop-blur supports-[backdrop-filter]:bg-card/70">
            <div className="flex h-16 items-center justify-between px-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="md:hidden bg-transparent"
                  onClick={() => setOpen(true)}
                  aria-expanded={open}
                  aria-controls="mobile-sidebar"
                >
                  <span className="sr-only">Open menu</span>Menu
                </Button>
                <div className="hidden md:block text-sm text-muted-foreground">Premium, futuristic UI</div>
              </div>
              <div className="flex items-center gap-2">
                <ThemeToggle />
              </div>
            </div>
          </header>

          {/* Main content area */}
          <main className="mx-auto w-full max-w-7xl px-6 py-6">{children}</main>
        </div>
      </div>
    </div>
  )
}
