"use client"

import { ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip, BarChart, Bar } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const pipelineData = [
  { month: "Jan", value: 620 },
  { month: "Feb", value: 680 },
  { month: "Mar", value: 740 },
  { month: "Apr", value: 710 },
  { month: "May", value: 820 },
  { month: "Jun", value: 860 },
]

const leadsBySource = [
  { source: "Website", leads: 420 },
  { source: "Referral", leads: 180 },
  { source: "Ads", leads: 260 },
  { source: "Events", leads: 130 },
  { source: "Outbound", leads: 210 },
]

function tooltipStyles() {
  return {
    contentStyle: {
      background: "var(--popover)",
      borderColor: "var(--border)",
      color: "var(--foreground)",
      borderRadius: "8px",
    },
    labelStyle: { color: "var(--foreground)" },
    itemStyle: { color: "var(--foreground)" },
  } as const
}

export function TrendCharts() {
  const styles = tooltipStyles()

  return (
    <section aria-label="Trends" className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">Pipeline Trend</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={pipelineData} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <YAxis
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <Tooltip {...styles} />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="var(--chart-1)"
                  fill="var(--chart-1)"
                  fillOpacity={0.2}
                  strokeWidth={2}
                  activeDot={{ r: 4, fill: "var(--chart-1)" }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">Leads by Source</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={leadsBySource} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="source"
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <YAxis
                  tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--border)" }}
                  tickLine={{ stroke: "var(--border)" }}
                />
                <Tooltip {...styles} />
                <Bar dataKey="leads" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
