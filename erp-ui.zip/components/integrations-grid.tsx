"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type Integration = {
  id: string
  name: string
  description: string
  category: "CRM" | "Messaging" | "Ads" | "Payments" | "Automation" | "Storage"
  connected: boolean
}

const seed: Integration[] = [
  {
    id: "I-slack",
    name: "Slack",
    description: "Channel notifications and alerts.",
    category: "Messaging",
    connected: true,
  },
  { id: "I-hubspot", name: "HubSpot", description: "Sync contacts and deals.", category: "CRM", connected: false },
  { id: "I-salesforce", name: "Salesforce", description: "Enterprise CRM sync.", category: "CRM", connected: false },
  {
    id: "I-google-ads",
    name: "Google Ads",
    description: "Import campaigns and spend.",
    category: "Ads",
    connected: true,
  },
  { id: "I-meta-ads", name: "Meta Ads", description: "Facebook & Instagram ads.", category: "Ads", connected: false },
  { id: "I-stripe", name: "Stripe", description: "Revenue and invoices.", category: "Payments", connected: false },
  { id: "I-zapier", name: "Zapier", description: "Automate workflows.", category: "Automation", connected: false },
  {
    id: "I-webhooks",
    name: "Webhooks",
    description: "Custom inbound/outbound hooks.",
    category: "Automation",
    connected: true,
  },
]

export function IntegrationsGrid() {
  const [items, setItems] = useState<Integration[]>(seed)
  const [query, setQuery] = useState("")
  const [category, setCategory] = useState<Integration["category"] | "All">("All")

  const filtered = items.filter((i) => {
    const match =
      i.name.toLowerCase().includes(query.toLowerCase()) || i.description.toLowerCase().includes(query.toLowerCase())
    const catOk = category === "All" ? true : i.category === category
    return match && catOk
  })

  function toggle(id: string) {
    setItems((arr) => arr.map((i) => (i.id === id ? { ...i, connected: !i.connected } : i)))
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div className="flex w-full max-w-md items-center gap-2">
          <input
            aria-label="Search integrations"
            className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2"
            placeholder="Search integrations…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Button
            variant="secondary"
            className="bg-secondary text-secondary-foreground hover:opacity-90"
            onClick={() => setQuery("")}
          >
            Clear
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="category" className="text-sm text-muted-foreground">
            Category
          </label>
          <select
            id="category"
            className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2"
            value={category}
            onChange={(e) => setCategory(e.target.value as any)}
          >
            <option>All</option>
            <option>CRM</option>
            <option>Messaging</option>
            <option>Ads</option>
            <option>Payments</option>
            <option>Automation</option>
            <option>Storage</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((i) => (
          <Card key={i.id} className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{i.name}</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="text-sm text-muted-foreground">{i.description}</div>
              <div className="flex items-center justify-between">
                <span
                  className={cn(
                    "inline-flex items-center rounded-full px-2 py-0.5 text-xs",
                    i.connected ? "bg-primary/10" : "bg-secondary/15",
                  )}
                >
                  {i.connected ? "Connected" : "Disconnected"}
                </span>
                <div className="flex items-center gap-2">
                  {i.connected ? (
                    <>
                      <Button size="sm" variant="outline" onClick={() => toggle(i.id)}>
                        Disconnect
                      </Button>
                      <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
                        Manage
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      className="bg-primary text-primary-foreground hover:opacity-90"
                      onClick={() => toggle(i.id)}
                    >
                      Connect
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full rounded-lg border bg-card p-6 text-center text-sm text-muted-foreground">
            No integrations found.
          </div>
        )}
      </div>
    </div>
  )
}
