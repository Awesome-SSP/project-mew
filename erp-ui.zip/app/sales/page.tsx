import Link from "next/link"

// Sales Overview page - server component
export default function SalesOverviewPage() {
  return (
    <main className="p-6 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl md:text-3xl font-semibold text-balance">Sales Overview</h1>
        <p className="text-muted-foreground">Quick access to key sales workflows and metrics.</p>
      </header>

      <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Link
          href="/leads"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Leads"
        >
          <div className="text-sm text-muted-foreground">Leads</div>
          <div className="mt-2 text-xl font-semibold">Manage Leads</div>
          <div className="mt-1 text-sm text-muted-foreground">Qualify, assign, and convert</div>
        </Link>
        <Link
          href="/pipeline"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Pipeline"
        >
          <div className="text-sm text-muted-foreground">Pipeline</div>
          <div className="mt-2 text-xl font-semibold">Opportunities</div>
          <div className="mt-1 text-sm text-muted-foreground">Track stages and value</div>
        </Link>
        <Link
          href="/accounts"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Accounts"
        >
          <div className="text-sm text-muted-foreground">Accounts</div>
          <div className="mt-2 text-xl font-semibold">Companies</div>
          <div className="mt-1 text-sm text-muted-foreground">View organizations & owners</div>
        </Link>
        <Link
          href="/quotes"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Quotes"
        >
          <div className="text-sm text-muted-foreground">Quotes</div>
          <div className="mt-2 text-xl font-semibold">Proposals</div>
          <div className="mt-1 text-sm text-muted-foreground">Draft and send quotes</div>
        </Link>
        <Link
          href="/invoices"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Invoices"
        >
          <div className="text-sm text-muted-foreground">Invoices</div>
          <div className="mt-2 text-xl font-semibold">Billing</div>
          <div className="mt-1 text-sm text-muted-foreground">Track status & payments</div>
        </Link>
        <Link
          href="/orders"
          className="rounded-lg border bg-card text-card-foreground p-4 hover:bg-accent/10 transition-colors"
          aria-label="Go to Orders"
        >
          <div className="text-sm text-muted-foreground">Orders</div>
          <div className="mt-2 text-xl font-semibold">Fulfillment</div>
          <div className="mt-1 text-sm text-muted-foreground">Manage shipments & status</div>
        </Link>
      </section>
    </main>
  )
}
