import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendCharts } from "@/components/trend-charts"

export default function Page() {
  return (
    <main className="mx-auto max-w-7xl">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-pretty text-3xl font-bold tracking-tight">Sales & Marketing ERP</h1>
          <p className="mt-1 text-muted-foreground">Premium, futuristic UI. Faster workflows. Fewer clicks.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button className="bg-primary text-primary-foreground hover:opacity-90">New Campaign</Button>
          <Button variant="secondary" className="bg-secondary text-secondary-foreground hover:opacity-90">
            Import Leads
          </Button>
        </div>
      </header>

      <section aria-label="KPI Overview" className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">2,431</div>
            <div className="mt-1 text-xs text-muted-foreground">+8.2% this week</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Opportunities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">317</div>
            <div className="mt-1 text-xs text-muted-foreground">Win rate 32%</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Pipeline Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">$842k</div>
            <div className="mt-1 text-xs text-muted-foreground">Forecast +$120k</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">ROI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">164%</div>
            <div className="mt-1 text-xs text-muted-foreground">Last 30 days</div>
          </CardContent>
        </Card>
      </section>

      <TrendCharts />

      <section aria-label="Quick Actions" className="mt-8">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-lg font-semibold">Quick actions</h2>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
              Add Lead
            </Button>
            <Button size="sm" variant="secondary" className="bg-secondary text-secondary-foreground hover:opacity-90">
              Create Pipeline
            </Button>
            <Button size="sm" variant="outline">
              Build Automation
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
