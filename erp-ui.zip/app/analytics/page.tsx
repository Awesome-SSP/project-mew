import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AnalyticsCharts } from "@/components/analytics-charts"
import { ReportsTable } from "@/components/reports-table"

export default function AnalyticsPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Analytics & Reporting</h1>
        <p className="mt-1 text-muted-foreground">Key KPIs, trends, and exportable reports—all in one place.</p>
      </header>

      {/* KPI Cards */}
      <section aria-label="KPI Overview" className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">MRR</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">$182k</div>
            <div className="mt-1 text-xs text-muted-foreground">+6.4% MoM</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">CAC</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">$312</div>
            <div className="mt-1 text-xs text-muted-foreground">-4.1% MoM</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">LTV</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">$1,640</div>
            <div className="mt-1 text-xs text-muted-foreground">+3.0% MoM</div>
          </CardContent>
        </Card>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Churn</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">2.1%</div>
            <div className="mt-1 text-xs text-muted-foreground">-0.3 pts MoM</div>
          </CardContent>
        </Card>
      </section>

      <AnalyticsCharts />

      <section aria-label="Reports" className="mt-8">
        <ReportsTable />
      </section>
    </main>
  )
}
