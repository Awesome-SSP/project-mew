import { CollaborationPanel } from "@/components/collaboration-panel"

export default function CollaborationPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Collaboration</h1>
        <p className="mt-1 text-muted-foreground">Share notes, manage tasks, and keep discussions in one place.</p>
      </header>
      <CollaborationPanel />
    </main>
  )
}
