import { IntegrationsGrid } from "@/components/integrations-grid"

export default function IntegrationsPage() {
  return (
    <main className="mx-auto w-full max-w-7xl">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-bold tracking-tight">Integrations</h1>
        <p className="mt-1 text-muted-foreground">Connect your CRM, messaging, ads, and automation tools.</p>
      </header>
      <IntegrationsGrid />
    </main>
  )
}
