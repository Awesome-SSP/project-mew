from crm.install import add_default_fields_layout


def execute():
	add_default_fields_layout()
