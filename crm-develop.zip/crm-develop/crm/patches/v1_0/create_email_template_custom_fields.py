
from crm.install import add_email_template_custom_fields

def execute():
    add_email_template_custom_fields()