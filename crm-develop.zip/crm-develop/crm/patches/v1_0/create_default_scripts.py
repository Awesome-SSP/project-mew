from crm.install import add_default_scripts


def execute():
	add_default_scripts()
