# Copyright (c) 2024, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
from frappe.tests import UnitTestCase


class TestCRMTerritory(UnitTestCase):
	pass
