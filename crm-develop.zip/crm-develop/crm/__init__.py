
__version__ = "2.0.0-dev"
__title__ = "Frappe CRM"

