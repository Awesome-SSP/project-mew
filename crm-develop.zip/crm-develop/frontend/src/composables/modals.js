import { ref } from 'vue';

export const showQuickEntryModal = ref(false);
export const quickEntryProps = ref({});

export const showAddressModal = ref(false);
export const addressProps = ref({});

export const showAboutModal = ref(false);

export const showChangePasswordModal = ref(false);