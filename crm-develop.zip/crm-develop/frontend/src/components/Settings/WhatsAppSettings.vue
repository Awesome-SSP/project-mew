<template>
  <SettingsPage doctype="WhatsApp Settings" class="p-8" />
</template>
<script setup>
import SettingsPage from '@/components/Settings/SettingsPage.vue'
</script>