<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle
      cx="8"
      cy="8"
      r="6.5"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-dasharray="1.9 1.9"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.5 14.9824C7.66515 14.9941 7.83188 15 8 15C11.866 15 15 11.866 15 8C15 4.13401 11.866 1 8 1C7.83188 1 7.66515 1.00593 7.5 1.01758V2.02054C7.66487 2.00694 7.83162 2 8 2C11.3137 2 14 4.68629 14 8C14 11.3137 11.3137 14 8 14C7.83162 14 7.66487 13.9931 7.5 13.9795V14.9824Z"
      fill="currentColor"
    />
    <path
      d="M6.55133 5.06237L10.9174 8.09973L6.54669 10.7899L6.55133 5.06237Z"
      stroke="currentColor"
    />
  </svg>
</template>
