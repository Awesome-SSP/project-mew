<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_1191_1930)">
      <path
        d="M1.45001 12.1V12.1C1.45001 11.7869 1.60364 11.4936 1.86111 11.3154L6.87595 7.84359C7.52855 7.39178 8.38658 7.36866 9.06257 7.78465L13.5984 10.5759C14.1276 10.9016 14.45 11.4786 14.45 12.1V12.1"
        stroke="currentColor"
      />
      <path
        d="M14.45 7.60001L11.95 9.60001M4.45001 9.60001L1.45001 7.60001"
        stroke="currentColor"
      />
      <path
        d="M4 9V3C4 2.44772 4.44772 2 5 2H11C11.5523 2 12 2.44772 12 3V9"
        stroke="currentColor"
      />
      <path
        d="M4 4.49999L2.1786 6C1.71727 6.37992 1.45002 6.94623 1.45002 7.54385L1.45002 12.1C1.45002 13.2046 2.34545 14.1 3.45002 14.1L12.45 14.1C13.5546 14.1 14.45 13.2046 14.45 12.1V7.51988C14.45 6.93603 14.1949 6.38133 13.7516 6.00137L12 4.5"
        stroke="currentColor"
      />
      <path d="M6 6H10" stroke="currentColor" stroke-linecap="round" />
      <path d="M6 4H9" stroke="currentColor" stroke-linecap="round" />
    </g>
  </svg>
</template>
